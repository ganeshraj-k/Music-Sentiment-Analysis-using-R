Spotify_EDA.rmd :
 is to get the currently popular albums of the chosen artists
and some Visualisations based on metadata for those albums.

data_extraction.rmd :
Extracting the song lyrics data using geniusr api and converting 
it to csv format

Sentiment_analysis_final.rmd:
 cleaning the data and performing sentiment analysis

mmlyrics.csv:
Eminem's album's lyrics

LPlyrics.csv:
Linkin park's album's lyrics

Billie.csv:
Billie Eilish's albums's lyrics

taylorlyrics.csv
Taylor Swift's album's lyrics

data_full.csv
combined lyrics data for all the 4 artists

